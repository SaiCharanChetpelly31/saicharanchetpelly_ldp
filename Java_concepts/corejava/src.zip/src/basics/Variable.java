package basics;
//variabble,constants and datatypes
public class Variable {
    public static void main(String[] args) {
        int myAge;   //declaration
        myAge = 19;  //initialization

        final int SOME_NUM = 150;

        String name = "sai charan";

        String myHomeTown = "Hyd";

        //string concatenation
        System.out.println(name + " is " + myAge);
        System.out.println(myHomeTown);
    }
}
