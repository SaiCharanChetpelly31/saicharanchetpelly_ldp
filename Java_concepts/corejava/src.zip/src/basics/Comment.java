package basics;/*
    John Baugh
    Learning Some Java 101
    This is a multiline comment
    July 30, 2060
 */

public class Comment {
    /*
        main is the entry point to the application.
     */

    public static void main(String[] args) {
        System.out.println("Printing stuff");  //print stuff to console
        //this doesn't print
        //these are single line comments
    }//end main
}
